import type { Topic } from "./types";
import { passportTopic, nationalIdTopic, birthCertTopic, trafficTopic } from "./a";
import { electricityTopic, waterTopic, telecomTopic, taxTopic } from "./b";
import { customsTopic, healthInsuranceTopic, pensionTopic, takafulTopic } from "./c";
import { rationTopic, universityTopic, schoolTopic, businessTopic } from "./d";
import { realestateTopic, localAdminTopic, msmeTopic, postTopic } from "./e";

export const TOPICS: Topic[] = [
  passportTopic,
  nationalIdTopic,
  birthCertTopic,
  trafficTopic,
  electricityTopic,
  waterTopic,
  telecomTopic,
  taxTopic,
  customsTopic,
  healthInsuranceTopic,
  pensionTopic,
  takafulTopic,
  rationTopic,
  universityTopic,
  schoolTopic,
  businessTopic,
  realestateTopic,
  localAdminTopic,
  msmeTopic,
  postTopic,
];

export type { Topic } from "./types";
