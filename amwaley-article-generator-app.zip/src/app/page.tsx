import AppShell from "@/components/app-shell";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <main>
      <AppShell />
    </main>
  );
}
