import { NextResponse } from "next/server";
import { count, desc } from "drizzle-orm";
import { db } from "@/db";
import { articles, generations } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const gens = await db
      .select()
      .from(generations)
      .orderBy(desc(generations.id))
      .limit(80);

    const counts = await db
      .select({ generationId: articles.generationId, value: count() })
      .from(articles)
      .groupBy(articles.generationId);

    const countMap = new Map(counts.map((c) => [c.generationId, c.value]));

    return NextResponse.json({
      ok: true,
      generations: gens.map((g) => ({
        id: g.id,
        dayKey: g.dayKey,
        batchNo: g.batchNo,
        createdAt: g.createdAt,
        articleCount: countMap.get(g.id) ?? 0,
      })),
    });
  } catch (error) {
    console.error("history error", error);
    return NextResponse.json({ ok: false, error: "تعذر تحميل السجل" }, { status: 500 });
  }
}
