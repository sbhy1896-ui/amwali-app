import { NextRequest, NextResponse } from "next/server";
import { count, eq } from "drizzle-orm";
import { db } from "@/db";
import { articles, generations } from "@/db/schema";
import { generateBatch, todayKey } from "@/lib/generator";

export const dynamic = "force-dynamic";

export async function POST(req: NextRequest) {
  try {
    const body = (await req.json().catch(() => ({}))) as { dayKey?: string };
    const dayKey =
      typeof body.dayKey === "string" && /^\d{4}-\d{2}-\d{2}$/.test(body.dayKey)
        ? body.dayKey
        : todayKey();

    const rows = await db.select({ fingerprint: articles.fingerprint }).from(articles);
    const existing = new Set(rows.map((r) => r.fingerprint));

    const batch = generateBatch(dayKey, existing, 8);

    const existingGens = await db
      .select({ value: count() })
      .from(generations)
      .where(eq(generations.dayKey, dayKey));
    const batchNo = (existingGens[0]?.value ?? 0) + 1;

    const [gen] = await db
      .insert(generations)
      .values({ dayKey, batchNo })
      .returning();

    const inserted = await db
      .insert(articles)
      .values(
        batch.map((a) => ({
          generationId: gen.id,
          fingerprint: a.fingerprint,
          topicId: a.topicId,
          category: a.category,
          title: a.title,
          intro: a.intro,
          body: a.body,
          keywords: a.keywords,
          imagePrompts: a.imagePrompts,
        })),
      )
      .returning();

    return NextResponse.json({
      ok: true,
      dayKey,
      batchNo: gen.batchNo,
      generationId: gen.id,
      createdAt: gen.createdAt,
      articles: inserted,
    });
  } catch (error) {
    console.error("generate error", error);
    return NextResponse.json(
      { ok: false, error: "تعذر توليد المقالات، حاول مرة أخرى" },
      { status: 500 },
    );
  }
}
