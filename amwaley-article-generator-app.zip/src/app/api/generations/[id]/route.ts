import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { articles, generations } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const genId = Number(id);
    if (!Number.isInteger(genId) || genId <= 0) {
      return NextResponse.json({ ok: false, error: "معرّف غير صالح" }, { status: 400 });
    }

    const [gen] = await db.select().from(generations).where(eq(generations.id, genId));
    if (!gen) {
      return NextResponse.json({ ok: false, error: "الدفعة غير موجودة" }, { status: 404 });
    }

    const arts = await db
      .select()
      .from(articles)
      .where(eq(articles.generationId, genId));

    return NextResponse.json({
      ok: true,
      generation: gen,
      articles: arts,
    });
  } catch (error) {
    console.error("generation detail error", error);
    return NextResponse.json({ ok: false, error: "تعذر تحميل الدفعة" }, { status: 500 });
  }
}
