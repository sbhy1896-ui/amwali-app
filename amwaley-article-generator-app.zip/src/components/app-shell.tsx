"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ArticleDTO, BatchResponse, GenerationDTO } from "@/lib/dto";
import { downloadBatch, articleToMarkdown } from "@/lib/download";
import ArticleCard from "./article-card";
import { FixerPanel, HistoryPanel } from "./panels";
import CopyButton, { copyText, toast } from "./copy-button";
import InstallCard from "./install-card";

type Tab = "generator" | "history" | "fixer";

function todayKeyLocal(): string {
  return new Date().toLocaleDateString("en-CA", { timeZone: "Africa/Cairo" });
}

export default function AppShell() {
  const [tab, setTab] = useState<Tab>("generator");
  const [batch, setBatch] = useState<BatchResponse | null>(null);
  const [history, setHistory] = useState<GenerationDTO[]>([]);
  const [historyLoading, setHistoryLoading] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [openedGen, setOpenedGen] = useState<{
    gen: GenerationDTO;
    articles: ArticleDTO[];
  } | null>(null);
  const [opening, setOpening] = useState(false);
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const articlesRef = useRef<HTMLDivElement>(null);

  const refreshHistory = useCallback(async () => {
    const r = await fetch("/api/history");
    const d = await r.json();
    if (d.ok) setHistory(d.generations);
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        await refreshHistory();
        const today = todayKeyLocal();
        const r = await fetch("/api/history");
        const d = await r.json();
        if (mounted && d.ok) {
          const todays = d.generations.filter((g: GenerationDTO) => g.dayKey === today);
          if (todays.length) {
            const r2 = await fetch(`/api/generations/${todays[0].id}`);
            const d2 = await r2.json();
            if (d2.ok && mounted) {
              setBatch({
                ok: true,
                dayKey: d2.generation.dayKey,
                batchNo: d2.generation.batchNo,
                generationId: d2.generation.id,
                createdAt: d2.generation.createdAt,
                articles: d2.articles,
              });
            }
          }
        }
      } catch {
        /* تجاهل */
      } finally {
        if (mounted) setHistoryLoading(false);
      }
    })();

    const onToast = (e: Event) => {
      setToastMsg((e as CustomEvent<string>).detail);
      window.setTimeout(() => setToastMsg(null), 2400);
    };
    window.addEventListener("amwal-toast", onToast);

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add("revealed");
            observer.unobserve(en.target);
          }
        });
      },
      { threshold: 0.08 },
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));

    return () => {
      mounted = false;
      window.removeEventListener("amwal-toast", onToast);
      observer.disconnect();
    };
  }, [refreshHistory]);

  // مراقبة العناصر المضافة لاحقًا
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((en) => {
          if (en.isIntersecting) {
            en.target.classList.add("revealed");
            observer.unobserve(en.target);
          }
        });
      },
      { threshold: 0.06 },
    );
    const t = window.setTimeout(() => {
      document.querySelectorAll(".reveal:not(.revealed)").forEach((el) => observer.observe(el));
    }, 60);
    return () => {
      window.clearTimeout(t);
      observer.disconnect();
    };
  }, [batch, openedGen, tab, history]);

  const generate = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const r = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dayKey: todayKeyLocal() }),
      });
      const d = (await r.json()) as BatchResponse;
      if (!d.ok) {
        setError("تعذر التوليد، حاول مرة أخرى");
        return;
      }
      setBatch(d);
      setOpenedGen(null);
      await refreshHistory();
      toast("تم توليد ٨ مقالات جديدة بنجاح ✓");
      window.setTimeout(
        () => articlesRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
        120,
      );
    } catch {
      setError("تعذر الاتصال بالخادم");
    } finally {
      setLoading(false);
    }
  }, [refreshHistory]);

  const openGeneration = useCallback(async (id: number) => {
    setOpening(true);
    setOpenedGen(null);
    try {
      const r = await fetch(`/api/generations/${id}`);
      const d = await r.json();
      if (d.ok) {
        setOpenedGen({ gen: d.generation, articles: d.articles });
        window.setTimeout(
          () => articlesRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }),
          100,
        );
      }
    } catch {
      toast("تعذر تحميل الدفعة");
    } finally {
      setOpening(false);
    }
  }, []);

  const copyAllArticles = useCallback(() => {
    if (!batch) return;
    const all = batch.articles.map(articleToMarkdown).join("\n\n" + "═".repeat(40) + "\n\n");
    copyText(all);
    toast("تم نسخ جميع مقالات الدفعة كاملة ✓");
  }, [batch]);

  const stats = useMemo(() => {
    const totalArticles = history.reduce((a, g) => a + (g.articleCount ?? 0), 0);
    const days = new Set(history.map((g) => g.dayKey)).size;
    return { totalArticles, days, batches: history.length };
  }, [history]);

  const currentArticles: ArticleDTO[] = openedGen ? openedGen.articles : batch?.articles ?? [];
  const batchMeta = openedGen
    ? { dayKey: openedGen.gen.dayKey, batchNo: openedGen.gen.batchNo }
    : batch
      ? { dayKey: batch.dayKey, batchNo: batch.batchNo }
      : null;

  return (
    <div className="min-h-screen">
      {/* التوست */}
      {toastMsg && (
        <div className="toast">
          <span aria-hidden>✓</span> {toastMsg}
        </div>
      )}

      {/* الترويسة */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#070d0a]/85 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <span className="logo-mark">م</span>
            <div>
              <div className="text-base font-black leading-5 text-white">
                مساعد مقالات <span className="gold-text">أموالي</span>
              </div>
              <div className="text-[10px] text-emerald-100/50">
                مولد المقالات الديناميكي اللانهائي — خدمات الحكومة المصرية
              </div>
            </div>
          </div>
          <nav className="flex items-center gap-1 rounded-2xl border border-white/10 bg-white/[0.03] p-1">
            {(
              [
                ["generator", "🚀 المولّد", null],
                ["history", "🗓️ السجل", history.length],
                ["fixer", "🛠️ معالج المراجعات", null],
              ] as const
            ).map(([key, label, count]) => (
              <button
                key={key}
                type="button"
                onClick={() => setTab(key)}
                className={`tab-btn ${tab === key ? "tab-btn-active" : ""}`}
              >
                {label}
                {count !== null && count > 0 && (
                  <span className="mr-1 rounded-full bg-emerald-400/20 px-1.5 text-[10px] font-bold text-emerald-300">
                    {count}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>
      </header>

      {/* الواجهة الرئيسية */}
      {tab === "generator" && (
        <>
          <section className="hero">
            <div className="hero-orb hero-orb-1" />
            <div className="hero-orb hero-orb-2" />
            <div className="relative mx-auto max-w-6xl px-4 pb-14 pt-12 text-center sm:px-6 sm:pt-16">
              <span className="hero-badge reveal">∞ توليد يومي لانهائي — بلا حدود ولا توقف</span>
              <h1 className="hero-title reveal">
                مقالات جديدة كل يوم،
                <br />
                <span className="gold-text">بضغطة زر واحدة</span>
              </h1>
              <p className="mx-auto mt-5 max-w-2xl text-sm leading-8 text-emerald-100/70 sm:text-base reveal">
                مولد ديناميكي ذكي ينتج ٨ مقالات حصرية عن الخدمات الحكومية
                المصرية: عنوانًا وتصنيفًا، مقدمة قصيرة، متنًا يتجاوز ٤٠٠ كلمة
                بستة عناوين فرعية على الأقل وروابط حكومية رسمية، وكلمات مفتاحية،
                وبرومبتات صور 4:3 — مع سجل كامل لكل يوم.
              </p>

              {/* الإحصائيات */}
              <div className="mx-auto mt-8 grid max-w-3xl grid-cols-3 gap-3 reveal">
                <div className="stat-card">
                  <div className="stat-value">{stats.totalArticles}</div>
                  <div className="stat-label">مقال مولّد</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value">{stats.days}</div>
                  <div className="stat-label">أيام التوليد</div>
                </div>
                <div className="stat-card">
                  <div className="stat-value">{stats.batches}</div>
                  <div className="stat-label">دفعة محفوظة</div>
                </div>
              </div>

              {/* زر التوليد */}
              <div className="mt-9 flex flex-col items-center gap-3 reveal">
                <button
                  type="button"
                  onClick={generate}
                  disabled={loading}
                  className="generate-btn"
                >
                  {loading ? (
                    <>
                      <span className="spinner spinner-light" />
                      جارٍ توليد ٨ مقالات جديدة…
                    </>
                  ) : (
                    <>
                      <span aria-hidden>⚡</span>
                      توليد 8 مقالات جديدة اليوم
                      <span className="generate-btn-inf">∞</span>
                    </>
                  )}
                </button>
                {error && (
                  <p className="text-sm font-bold text-rose-300">⚠️ {error}</p>
                )}
                {batch && !loading && (
                  <div className="flex flex-wrap items-center justify-center gap-3">
                    <button
                      type="button"
                      onClick={() => downloadBatch(batch.articles, batch.dayKey, batch.batchNo)}
                      className="btn-ghost"
                    >
                      ⬇️ تحميل الدفعة الحالية (DOC)
                    </button>
                    <button type="button" onClick={copyAllArticles} className="btn-ghost">
                      📋 نسخ جميع المقالات
                    </button>
                    <span className="text-[11px] text-emerald-100/50">
                      الدفعة رقم {batch.batchNo} — {new Date(batch.dayKey + "T12:00:00").toLocaleDateString("ar-EG", { weekday: "long", day: "numeric", month: "long" })}
                    </span>
                  </div>
                )}
              </div>

              <InstallCard />
            </div>
          </section>

          {/* المقالات */}
          <section ref={articlesRef} className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
            {currentArticles.length === 0 && !historyLoading && (
              <div className="grid place-items-center rounded-3xl border border-dashed border-emerald-300/25 py-16 text-center reveal">
                <div className="text-5xl">📰</div>
                <h3 className="mt-4 text-lg font-extrabold text-white">
                  لا توجد مقالات معروضة بعد
                </h3>
                <p className="mt-2 max-w-md text-sm leading-7 text-emerald-100/60">
                  اضغط زر «توليد 8 مقالات جديدة اليوم» بالأعلى، وسيظهر هنا ٨
                  مقالات حصرية جديدة مع أزرار نسخ وتحميل لكل جزء.
                </p>
              </div>
            )}

            {opening && (
              <div className="grid gap-3 sm:grid-cols-2">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="h-64 animate-pulse rounded-3xl bg-white/5" />
                ))}
              </div>
            )}

            {currentArticles.length > 0 && (
              <>
                <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
                  <h2 className="text-xl font-black text-white">
                    {openedGen ? "📚 مقالات الدفعة المختارة" : "✨ الدفعة الحالية"}
                    <span className="mr-2 text-sm font-bold text-emerald-300">
                      ({currentArticles.length} مقالات)
                    </span>
                  </h2>
                  {batchMeta && (
                    <div className="flex items-center gap-2">
                      {openedGen && (
                        <button
                          type="button"
                          onClick={() => setOpenedGen(null)}
                          className="copy-btn"
                        >
                          <span aria-hidden>↩</span>
                          <span>العودة للدفعة الحالية</span>
                        </button>
                      )}
                      <CopyButton
                        text={currentArticles
                          .map((a) => `${a.title}\n${a.category}\n${a.intro}\n\n${a.body}`)
                          .join("\n\n" + "═".repeat(30) + "\n\n")}
                        label="محتوى كل المقالات نصيًا"
                      />
                      <button
                        type="button"
                        className="btn-ghost"
                        onClick={() =>
                          downloadBatch(currentArticles, batchMeta.dayKey, batchMeta.batchNo)
                        }
                      >
                        ⬇️ تحميل الدفعة (DOC)
                      </button>
                    </div>
                  )}
                </div>
                <div className="grid gap-5 lg:grid-cols-2">
                  {currentArticles.map((a, i) => (
                    <ArticleCard key={a.id} article={a} index={i} />
                  ))}
                </div>
              </>
            )}
          </section>
        </>
      )}

      {tab === "history" && (
        <section className="mx-auto max-w-6xl px-4 pb-20 pt-10 sm:px-6">
          <div className="mb-6 reveal">
            <h2 className="text-2xl font-black text-white">
              🗓️ سجل التوليد اليومي
            </h2>
            <p className="mt-2 text-sm leading-7 text-emerald-100/60">
              كل دفعة تُولَّد تُحفظ هنا تلقائيًا مع يومها ورقمها. يمكنك العودة
              لأي يوم سابق واستعراض مقالاته أو تحميلها في أي وقت — بلا حدود.
            </p>
          </div>
          <HistoryPanel
            history={history}
            loading={historyLoading}
            activeId={openedGen?.gen.id ?? null}
            onOpen={openGeneration}
          />
          {openedGen && (
            <div ref={articlesRef} className="mt-8">
              <div className="mb-4 flex items-center justify-between">
                <h3 className="text-lg font-extrabold text-white">
                  مقالات الدفعة رقم {openedGen.gen.batchNo}
                </h3>
                <button
                  type="button"
                  onClick={() => setOpenedGen(null)}
                  className="copy-btn"
                >
                  <span aria-hidden>↩</span>
                  <span>مسح الاختيار</span>
                </button>
              </div>
              <div className="grid gap-5 lg:grid-cols-2">
                {openedGen.articles.map((a, i) => (
                  <ArticleCard key={a.id} article={a} index={i} />
                ))}
              </div>
            </div>
          )}
        </section>
      )}

      {tab === "fixer" && (
        <section className="mx-auto max-w-6xl px-4 pb-20 pt-10 sm:px-6">
          <div className="mb-6 reveal">
            <h2 className="text-2xl font-black text-white">
              🛠️ معالجة المراجعات بالذكاء الاصطناعي
            </h2>
            <p className="mt-2 max-w-2xl text-sm leading-7 text-emerald-100/60">
              الصق اعتراض المراجع وسيقوم المعالج بتوليد فقرة بديلة عربية
              موضعية فقط، مدعومة بروابط حكومية رسمية مباشرة حسب الموضوع
              المكتشف.
            </p>
          </div>
          <div className="reveal">
            <FixerPanel />
          </div>
        </section>
      )}

      {/* الفوتر */}
      <footer className="border-t border-white/10 py-8 text-center text-[12px] leading-7 text-emerald-100/40">
        <div className="mx-auto max-w-6xl px-4">
          <div className="font-black text-emerald-100/60">
            مساعد مقالات أموالي — مولد لانهائي بلا بيانات ثابتة
          </div>
          <div className="mt-1">
            كل مقال يُولَّد ديناميكيًا من محرك المحتوى ويُحفظ في سجل يومك •
            الخدمات الحكومية المصرية • تحديث يومي بلا حدود
          </div>
        </div>
      </footer>
    </div>
  );
}
