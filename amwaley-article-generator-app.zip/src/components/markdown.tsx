import type { ReactNode } from "react";

export function renderInline(text: string): ReactNode[] {
  const parts: ReactNode[] = [];
  const re = /\[([^\]]+)\]\((https?:\/\/[^)]+)\)|\*\*([^*]+)\*\*/g;
  let last = 0;
  let key = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > last) parts.push(text.slice(last, m.index));
    if (m[1] !== undefined) {
      parts.push(
        <a
          key={key++}
          href={m[2]}
          target="_blank"
          rel="noreferrer"
          className="inline-link"
        >
          {m[1]}
        </a>,
      );
    } else if (m[3] !== undefined) {
      parts.push(<strong key={key++} className="font-bold text-emerald-200">{m[3]}</strong>);
    }
    last = m.index + m[0].length;
  }
  if (last < text.length) parts.push(text.slice(last));
  return parts;
}

export function MarkdownBody({ body }: { body: string }) {
  const blocks = body.split(/\n\n+/).filter(Boolean);
  return (
    <div className="space-y-4 text-[15px] leading-8 text-emerald-50/90">
      {blocks.map((b, i) => {
        if (b.startsWith("## ")) {
          return (
            <h3 key={i} className="md-h2">
              <span className="md-h2-icon" aria-hidden>✦</span>
              {b.slice(3)}
            </h3>
          );
        }
        if (b.startsWith("> ")) {
          return (
            <div key={i} className="md-advisory">
              {renderInline(b.slice(2))}
            </div>
          );
        }
        const lines = b.split("\n").map((l) => l.trim());
        if (lines.length > 1 && lines.every((l) => l.startsWith("- "))) {
          return (
            <ul key={i} className="space-y-2 pr-5 list-disc marker:text-emerald-400">
              {lines.map((l, j) => (
                <li key={j}>{renderInline(l.slice(2))}</li>
              ))}
            </ul>
          );
        }
        return <p key={i}>{renderInline(b)}</p>;
      })}
    </div>
  );
}
