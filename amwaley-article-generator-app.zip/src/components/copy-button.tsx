"use client";

import { useState } from "react";

export function toast(msg: string) {
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("amwal-toast", { detail: msg }));
  }
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
      return true;
    } catch {
      return false;
    }
  }
}

interface CopyButtonProps {
  text: string;
  label?: string;
  className?: string;
  iconOnly?: boolean;
  successText?: string;
}

export default function CopyButton({
  text,
  label,
  className = "",
  iconOnly = false,
  successText = "تم النسخ ✓",
}: CopyButtonProps) {
  const [copied, setCopied] = useState(false);

  const handle = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const ok = await copyText(text);
    if (ok) {
      setCopied(true);
      toast(`تم نسخ ${label ?? "النص"} بنجاح`);
      setTimeout(() => setCopied(false), 1800);
    } else {
      toast("تعذر النسخ، حاول مجددًا");
    }
  };

  return (
    <button
      type="button"
      onClick={handle}
      title={`نسخ ${label ?? "النص"}`}
      className={`copy-btn ${copied ? "copy-btn-copied" : ""} ${className}`}
    >
      <span aria-hidden>{copied ? "✓" : "📋"}</span>
      {!iconOnly && <span>{copied ? successText : "نسخ"}</span>}
    </button>
  );
}
