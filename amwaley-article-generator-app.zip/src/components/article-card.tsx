"use client";

import { useState } from "react";
import type { ArticleDTO } from "@/lib/dto";
import { downloadArticle } from "@/lib/download";
import { MarkdownBody } from "./markdown";
import CopyButton from "./copy-button";

export default function ArticleCard({
  article,
  index,
}: {
  article: ArticleDTO;
  index: number;
}) {
  const [open, setOpen] = useState(true);
  const wordCount = article.body.split(/\s+/).filter(Boolean).length;
  const h2Count = (article.body.match(/^## /gm) ?? []).length;

  const titleCopy = `${article.title}\nالتصنيف: ${article.category}`;

  return (
    <article className="article-card reveal">
      {/* الترويسة */}
      <header className="flex items-start justify-between gap-3 border-b border-white/10 pb-4">
        <div className="flex items-center gap-3">
          <span className="article-index">{index + 1}</span>
          <div>
            <span className="category-badge">{article.category}</span>
            <div className="mt-1 flex items-center gap-2 text-[11px] text-emerald-200/50">
              <span>✍️ {wordCount} كلمة</span>
              <span>•</span>
              <span>📑 {h2Count} عنوانًا فرعيًا</span>
            </div>
          </div>
        </div>
        <CopyButton text={titleCopy} label="العنوان والتصنيف" iconOnly />
      </header>

      {/* العنوان */}
      <h2 className="mt-4 text-xl font-extrabold leading-9 text-white">
        {article.title}
      </h2>

      {/* المقدمة */}
      <div className="mt-3 rounded-2xl border border-emerald-300/15 bg-emerald-400/[0.06] p-4">
        <div className="mb-2 flex items-center justify-between">
          <span className="text-xs font-bold text-emerald-300">
            المقدمة (أقل من ٢٦٠ حرفًا)
          </span>
          <CopyButton text={article.intro} label="المقدمة" />
        </div>
        <p className="text-sm leading-7 text-emerald-50/85">{article.intro}</p>
      </div>

      {/* المتن */}
      <div className="mt-5 rounded-2xl border border-white/10 bg-black/20 p-4 sm:p-5">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <span className="text-xs font-bold text-emerald-300">
            المتن الكامل (٦ عناوين فأكثر + روابط حكومية موثقة)
          </span>
          <div className="flex items-center gap-2">
            <CopyButton text={article.body} label="المتن الكامل" />
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              className="copy-btn"
            >
              <span aria-hidden>{open ? "▲" : "▼"}</span>
              <span>{open ? "إخفاء" : "عرض"}</span>
            </button>
          </div>
        </div>
        {open && <MarkdownBody body={article.body} />}
      </div>

      {/* الكلمات المفتاحية */}
      <div className="mt-5">
        <div className="mb-2 text-xs font-bold text-emerald-300">
          5 كلمات مفتاحية
        </div>
        <div className="flex flex-wrap gap-2">
          {article.keywords.map((kw) => (
            <span key={kw} className="keyword-chip">
              <span>{kw}</span>
              <CopyButton text={kw} label={`كلمة «${kw}»`} iconOnly className="keyword-copy" />
            </span>
          ))}
        </div>
      </div>

      {/* برومبتات الصور */}
      <div className="mt-5">
        <div className="mb-2 text-xs font-bold text-emerald-300">
          برومبتات الصور (4:3) — للمقال ولكل عنوان فرعي
        </div>
        <div className="space-y-2">
          <div className="prompt-row">
            <span className="prompt-label">🖼️ صورة المقال الرئيسية</span>
            <div className="flex min-w-0 flex-1 items-start gap-2">
              <p className="min-w-0 flex-1 text-[12px] leading-6 text-emerald-50/70" dir="ltr">
                {article.imagePrompts.article}
              </p>
              <CopyButton text={article.imagePrompts.article} label="برومبت صورة المقال" iconOnly />
            </div>
          </div>
          {article.imagePrompts.sections.map((p, i) => (
            <div key={i} className="prompt-row">
              <span className="prompt-label">🖼️ القسم {i + 1}</span>
              <div className="flex min-w-0 flex-1 items-start gap-2">
                <p className="min-w-0 flex-1 text-[12px] leading-6 text-emerald-50/70" dir="ltr">
                  {p}
                </p>
                <CopyButton text={p} label={`برومبت صورة القسم ${i + 1}`} iconOnly />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* التحميلات */}
      <footer className="mt-5 flex flex-wrap items-center gap-2 border-t border-white/10 pt-4">
        <span className="text-[11px] font-bold text-emerald-200/60">
          ⬇️ تحميل المقال:
        </span>
        <button type="button" className="dl-btn" onClick={() => downloadArticle(article, "doc")}>
          DOC
        </button>
        <button type="button" className="dl-btn" onClick={() => downloadArticle(article, "md")}>
          Markdown
        </button>
        <button type="button" className="dl-btn" onClick={() => downloadArticle(article, "txt")}>
          TXT
        </button>
      </footer>
    </article>
  );
}
