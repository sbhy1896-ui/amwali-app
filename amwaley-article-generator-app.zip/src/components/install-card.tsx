"use client";

import { useEffect, useState } from "react";
import { copyText, toast } from "./copy-button";

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

export default function InstallCard() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [showHelp, setShowHelp] = useState(false);
  const [origin, setOrigin] = useState("");

  useEffect(() => {
    setOrigin(window.location.origin);
    const onPrompt = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setDeferred(null);
      toast("تم تثبيت التطبيق على هاتفك 🎉");
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  const install = async () => {
    if (!deferred) {
      setShowHelp((v) => !v);
      return;
    }
    await deferred.prompt();
    const choice = await deferred.userChoice;
    if (choice.outcome === "accepted") toast("جارٍ تثبيت التطبيق…");
    setDeferred(null);
  };

  const copyLink = async () => {
    const ok = await copyText(origin);
    if (ok) toast("تم نسخ رابط التطبيق — افتحه على هاتفك");
  };

  return (
    <div className="reveal mx-auto mt-8 max-w-2xl rounded-3xl border border-gold/30 bg-gold/[0.05] p-5 backdrop-blur-sm">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="logo-mark" style={{ width: 40, height: 40, fontSize: 18 }}>
            م
          </span>
          <div>
            <div className="font-heading text-sm font-black text-white">
              📱 ثبّت التطبيق على هاتفك
            </div>
            <div className="mt-0.5 text-[12px] leading-6 text-emerald-100/60">
              أضفه إلى الشاشة الرئيسية ليعمل كتطبيق مستقل بأيقونته — بدون
              متجر وبدون تسجيل
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button type="button" onClick={install} className="btn-primary !py-2.5 !px-5 !text-sm">
            {deferred ? "🚀 تثبيت فوري" : "📲 خطوات التثبيت"}
          </button>
          <button type="button" onClick={copyLink} className="btn-ghost !py-2.5 !px-4 !text-sm">
            🔗 نسخ الرابط
          </button>
        </div>
      </div>

      {showHelp && !deferred && (
        <div className="mt-4 grid gap-3 border-t border-gold/20 pt-4 sm:grid-cols-2">
          <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
            <div className="text-[12px] font-black text-emerald-300">
              🤖 أندرويد (كروم)
            </div>
            <ol className="mt-2 list-decimal space-y-1 pr-4 text-[12px] leading-6 text-emerald-100/70">
              <li>افتح الرابط في متصفح Chrome</li>
              <li>اضغط قائمة «⋮» أعلى الشاشة</li>
              <li>
                اختر «إضافة إلى الشاشة الرئيسية» أو «تثبيت التطبيق»
              </li>
            </ol>
          </div>
          <div className="rounded-2xl border border-white/10 bg-black/25 p-4">
            <div className="text-[12px] font-black text-emerald-300">
              🍎 آيفون (سفاري)
            </div>
            <ol className="mt-2 list-decimal space-y-1 pr-4 text-[12px] leading-6 text-emerald-100/70">
              <li>افتح الرابط في متصفح Safari</li>
              <li>اضغط زر «مشاركة» أسفل الشاشة</li>
              <li>اختر «إضافة إلى الشاشة الرئيسية»</li>
            </ol>
          </div>
          <div className="sm:col-span-2 rounded-2xl border border-dashed border-gold/30 bg-gold/[0.06] p-3 text-center">
            <div className="text-[11px] text-emerald-100/50">الرابط المباشر</div>
            <div dir="ltr" className="mt-1 truncate font-mono text-[13px] font-bold text-gold">
              {origin || "…"}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
