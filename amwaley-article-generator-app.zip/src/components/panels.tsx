"use client";

import { useState } from "react";
import type { FixResponse, GenerationDTO } from "@/lib/dto";
import { downloadBlob } from "@/lib/download";
import CopyButton, { toast } from "./copy-button";

/* ---------------- سجل الأيام والدفعات ---------------- */

export function HistoryPanel({
  history,
  loading,
  activeId,
  onOpen,
}: {
  history: GenerationDTO[];
  loading: boolean;
  activeId: number | null;
  onOpen: (id: number) => void;
}) {
  if (loading) {
    return (
      <div className="grid gap-3 sm:grid-cols-2">
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} className="h-24 animate-pulse rounded-2xl bg-white/5" />
        ))}
      </div>
    );
  }
  if (history.length === 0) {
    return (
      <div className="rounded-3xl border border-dashed border-emerald-300/20 p-10 text-center text-emerald-100/60">
        <div className="text-4xl">🗓️</div>
        <p className="mt-3 font-bold">لا توجد دفعات سابقة بعد</p>
        <p className="mt-1 text-sm">
          اضغط «توليد ٨ مقالات جديدة اليوم» وستُحفظ كل دفعة هنا تلقائيًا
        </p>
      </div>
    );
  }

  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {history.map((g) => {
        const d = new Date(g.dayKey + "T12:00:00");
        const dateLabel = d.toLocaleDateString("ar-EG", {
          weekday: "long",
          year: "numeric",
          month: "long",
          day: "numeric",
        });
        const isActive = activeId === g.id;
        return (
          <button
            key={g.id}
            type="button"
            onClick={() => onOpen(g.id)}
            className={`history-item ${isActive ? "history-item-active" : ""}`}
          >
            <div className="flex items-center justify-between">
              <span className="rounded-full bg-emerald-400/10 px-3 py-1 text-[11px] font-bold text-emerald-300">
                دفعة {g.batchNo}
              </span>
              <span className="text-[11px] text-emerald-100/50">
                {g.articleCount ?? 8} مقالات
              </span>
            </div>
            <div className="mt-3 font-extrabold text-white">{dateLabel}</div>
            <div className="mt-1 text-[12px] text-emerald-100/60">
              {new Date(g.createdAt).toLocaleTimeString("ar-EG", {
                hour: "2-digit",
                minute: "2-digit",
              })}{" "}
              — اضغط لعرض المقالات
            </div>
          </button>
        );
      })}
    </div>
  );
}

/* ---------------- معالج المراجعات (AI Review Fixer) ---------------- */

export function FixerPanel() {
  const [objection, setObjection] = useState("");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<FixResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    if (objection.trim().length < 4) {
      setError("اكتب نص اعتراض المراجعة أولًا");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/fix", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ objection }),
      });
      const data = (await res.json()) as FixResponse;
      if (!data.ok) {
        setError(data.paragraph || "تعذرت المعالجة");
        setResult(null);
      } else {
        setResult(data);
        toast("تم توليد الفقرة البديلة ✓");
      }
    } catch {
      setError("خطأ في الاتصال بالخادم");
    } finally {
      setBusy(false);
    }
  };

  const downloadParagraph = () => {
    if (!result) return;
    const content = [
      `الفقرة البديلة المقترحة`,
      ``,
      result.paragraph.replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, "$1 ($2)"),
      ``,
      `الروابط الرسمية الداعمة:`,
      ...result.links.map((l) => `- ${l.label}: ${l.url}`),
      ``,
      `الكلمات المفتاحية: ${result.keywords.join("، ")}`,
      ``,
      `— مساعد مقالات أموالي`,
    ].join("\n");
    downloadBlob(`amwal-fix-${Date.now()}.txt`, content, "text/plain");
    toast("تم تحميل الفقرة البديلة");
  };

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      {/* الإدخال */}
      <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 backdrop-blur-sm">
        <h3 className="text-lg font-extrabold text-white">
          🛠️ معالج اعتراضات المراجعات
        </h3>
        <p className="mt-1 text-sm leading-7 text-emerald-100/70">
          الصق اعتراض المراجع (مثل: رابط غير صحيح، معلومة ناقصة، صياغة غير
          موثقة) وسيتم توليد فقرة بديلة موضعية باللغة العربية مع روابط حكومية
          رسمية مباشرة.
        </p>
        <textarea
          value={objection}
          onChange={(e) => setObjection(e.target.value)}
          rows={9}
          placeholder="مثال: الرابط المذكور في فقرة سداد الفاتورة غير رسمي، والمطلوب استبداله برابط الجهة المختصة مع توثيق الرسوم…"
          className="mt-4 w-full resize-y rounded-2xl border border-emerald-300/20 bg-black/30 p-4 text-sm leading-8 text-emerald-50 placeholder:text-emerald-100/30 focus:border-emerald-400/60 focus:outline-none focus:ring-2 focus:ring-emerald-400/20"
        />
        {error && (
          <p className="mt-2 text-sm font-bold text-rose-300">⚠️ {error}</p>
        )}
        <button
          type="button"
          onClick={submit}
          disabled={busy}
          className="btn-primary mt-4 w-full disabled:opacity-60"
        >
          {busy ? (
            <span className="flex items-center justify-center gap-2">
              <span className="spinner" /> جارٍ المعالجة…
            </span>
          ) : (
            "⚡ إصلاح فوري"
          )}
        </button>
      </div>

      {/* النتيجة */}
      <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-5 backdrop-blur-sm">
        <h3 className="text-lg font-extrabold text-white">النتيجة</h3>
        {!result ? (
          <div className="mt-6 grid h-48 place-items-center rounded-2xl border border-dashed border-emerald-300/20 text-center text-sm text-emerald-100/50">
            ستظهر الفقرة البديلة هنا بعد الضغط على «إصلاح فوري»
          </div>
        ) : (
          <div className="mt-4 space-y-4">
            {result.topicCat && (
              <div className="flex flex-wrap items-center gap-2">
                <span className="rounded-full bg-emerald-400/10 px-3 py-1 text-[11px] font-bold text-emerald-300">
                  الموضوع المكتشف: {result.topicCat}
                </span>
                {result.keywords.slice(0, 5).map((k) => (
                  <span key={k} className="rounded-full bg-white/5 px-2.5 py-1 text-[11px] text-emerald-100/70">
                    {k}
                  </span>
                ))}
              </div>
            )}
            <div className="rounded-2xl border border-emerald-300/20 bg-emerald-400/[0.07] p-4">
              <div className="mb-2 flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-300">
                  الفقرة البديلة (نص فقط)
                </span>
                <CopyButton text={result.paragraph} label="الفقرة البديلة" />
              </div>
              <p className="text-sm leading-8 text-emerald-50/90">
                {result.paragraph}
              </p>
            </div>
            <div>
              <div className="mb-2 text-xs font-bold text-emerald-300">
                الروابط الحكومية الرسمية الداعمة:
              </div>
              <ul className="space-y-2">
                {result.links.map((l) => (
                  <li key={l.url}>
                    <a
                      href={l.url}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/20 px-3 py-2 text-sm text-emerald-200 transition hover:border-emerald-300/40"
                    >
                      <span aria-hidden>🔗</span>
                      <span className="font-bold">{l.label}</span>
                      <span className="truncate text-[11px] text-emerald-100/40" dir="ltr">
                        {l.url}
                      </span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <button
              type="button"
              onClick={downloadParagraph}
              className="btn-ghost w-full"
            >
              ⬇️ تحميل الفقرة البديلة (TXT)
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
