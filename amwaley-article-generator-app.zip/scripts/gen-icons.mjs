// توليد أيقونات PNG للتطبيق (PWA) بدون مكتبات خارجية
import zlib from "node:zlib";
import fs from "node:fs";
import path from "node:path";

const CRC_TABLE = (() => {
  const t = new Uint32Array(256);
  for (let n = 0; n < 256; n++) {
    let c = n;
    for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    t[n] = c >>> 0;
  }
  return t;
})();

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) c = CRC_TABLE[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const typeBuf = Buffer.from(type, "ascii");
  const crcBuf = Buffer.alloc(4);
  crcBuf.writeUInt32BE(crc32(Buffer.concat([typeBuf, data])), 0);
  return Buffer.concat([len, typeBuf, data, crcBuf]);
}

function encodePNG(w, h, rgba) {
  const raw = Buffer.alloc((w * 4 + 1) * h);
  for (let y = 0; y < h; y++) {
    raw[y * (w * 4 + 1)] = 0;
    rgba.copy(raw, y * (w * 4 + 1) + 1, y * w * 4, (y + 1) * w * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; // bit depth
  ihdr[9] = 6; // RGBA
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  return Buffer.concat([
    sig,
    chunk("IHDR", ihdr),
    chunk("IDAT", zlib.deflateSync(raw, { level: 9 })),
    chunk("IEND", Buffer.alloc(0)),
  ]);
}

function drawIcon(size) {
  const buf = Buffer.alloc(size * size * 4);
  const cx = size / 2;
  const cy = size / 2;
  const radius = size * 0.235; // نصف قطر الزخرفة الذهبية
  const ringW = size * 0.035;
  const corner = size * 0.22;

  const gold = [217, 164, 65];
  const goldLight = [245, 212, 137];
  const dark = [5, 46, 34];

  const inRounded = (x, y) => {
    const rx = Math.min(x, size - 1 - x);
    const ry = Math.min(y, size - 1 - y);
    if (rx >= corner || ry >= corner) return true;
    const dx = corner - rx;
    const dy = corner - ry;
    return dx * dx + dy * dy <= corner * corner;
  };

  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      const i = (y * size + x) * 4;
      if (!inRounded(x, y)) {
        buf[i + 3] = 0;
        continue;
      }
      // خلفية متدرجة زمردية
      const t = (x + y) / (2 * size);
      let r = Math.round(6 + (16 - 6) * t);
      let g = Math.round(94 + (185 - 94) * t);
      let b = Math.round(70 + (129 - 70) * t);
      let a = 255;

      const d = Math.hypot(x - cx, y - cy);
      // حلقة ذهبية
      if (Math.abs(d - radius) < ringW / 2) {
        r = gold[0]; g = gold[1]; b = gold[2];
      }
      // دائرة داكنة داخلية
      if (d < radius - ringW * 0.8) {
        r = dark[0]; g = dark[1]; b = dark[2];
      }
      // معيّن (∞) ذهبي في المنتصف
      if (Math.abs(x - cx) + Math.abs(y - cy) < size * 0.16) {
        r = goldLight[0]; g = goldLight[1]; b = goldLight[2];
      }
      // نقطة سفلية صغيرة
      if (Math.hypot(x - cx, y - (cy + radius)) < size * 0.022) {
        r = gold[0]; g = gold[1]; b = gold[2];
      }

      buf[i] = r; buf[i + 1] = g; buf[i + 2] = b; buf[i + 3] = a;
    }
  }
  return encodePNG(size, size, buf);
}

const outDir = path.join(process.cwd(), "public", "icons");
fs.mkdirSync(outDir, { recursive: true });

const sizes = { "icon-192.png": 192, "icon-512.png": 512, "apple-touch-icon.png": 180 };
for (const [name, size] of Object.entries(sizes)) {
  fs.writeFileSync(path.join(outDir, name), drawIcon(size));
  console.log("written", name, size + "x" + size);
}
